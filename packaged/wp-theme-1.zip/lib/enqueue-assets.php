<?php 

function wp-theme-1_assets() {
 wp_enqueue_style( 'wp-theme-1-stylesheet', get_template_directory_uri(  ) . '/dist/assets/css/bundle.css', array(), '1.0.0', 'all' );

 
 wp_enqueue_script( 'wp-theme-1-scripts', get_template_directory_uri() . '/dist/assets/js/bundle.js', array('jquery'), '1.0.0', true );
}

add_action('wp_enqueue_scripts', 'wp-theme-1_assets');

function wp-theme-1_admin_assets() {
 wp_enqueue_style( 'wp-theme-1-admin-stylesheet', get_template_directory_uri(  ) . '/dist/assets/css/admin.css', array(), '1.0.0', 'all' );

 wp_enqueue_script( 'wp-theme-1-admin_scripts', get_template_directory_uri() . '/dist/assets/js/admin.js', array(), '1.0.0', true );
}

add_action('admin_enqueue_scripts', 'wp-theme-1_admin_assets');

